import React, { useState } from 'react';
import { useData } from '../../contexts/DataContext';
import { Search, Play, Book, ArrowRight, Clock, Star } from 'lucide-react';

const Troubleshooting: React.FC = () => {
  const { troubleshootingGuides } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedGuide, setSelectedGuide] = useState<string | null>(null);

  const filteredGuides = troubleshootingGuides.filter(guide => {
    const matchesSearch = guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         guide.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || guide.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [...new Set(troubleshootingGuides.map(guide => guide.category))];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const selectedGuideData = selectedGuide ? 
    troubleshootingGuides.find(guide => guide.id === selectedGuide) : null;

  if (selectedGuide && selectedGuideData) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center space-x-4 mb-6">
          <button
            onClick={() => setSelectedGuide(null)}
            className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowRight className="h-5 w-5 mr-2 rotate-180" />
            Back to Guides
          </button>
          <div className="text-gray-400">|</div>
          <span className="text-gray-600">{selectedGuideData.category}</span>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6">
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{selectedGuideData.title}</h1>
                <p className="text-gray-600 mb-4">{selectedGuideData.description}</p>
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 text-sm font-medium rounded-full ${getDifficultyColor(selectedGuideData.difficulty)}`}>
                    {selectedGuideData.difficulty}
                  </span>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    5-10 minutes
                  </div>
                </div>
              </div>
            </div>

            {selectedGuideData.imageUrl && (
              <div className="mb-6">
                <img
                  src={selectedGuideData.imageUrl}
                  alt={selectedGuideData.title}
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
            )}

            {selectedGuideData.videoUrl && (
              <div className="mb-6 bg-gray-900 rounded-lg p-6 text-center">
                <div className="flex items-center justify-center space-x-3 text-white">
                  <Play className="h-8 w-8" />
                  <div>
                    <h3 className="font-medium">Video Tutorial</h3>
                    <p className="text-sm text-gray-300">Click to watch the step-by-step guide</p>
                  </div>
                </div>
              </div>
            )}

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Step-by-Step Instructions</h3>
              <div className="space-y-4">
                {selectedGuideData.steps.map((step, index) => (
                  <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-medium text-sm">
                      {index + 1}
                    </div>
                    <p className="text-gray-700 flex-1">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Still Need Help?</h4>
              <p className="text-blue-800 text-sm mb-3">
                If these steps don't resolve your issue, you can create a support ticket or contact IT directly.
              </p>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                Create Support Ticket
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Troubleshooting Guides</h1>
        <p className="text-gray-600">Find step-by-step solutions to common IT issues</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search troubleshooting guides..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Categories</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Quick Tips */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
        <div className="flex items-center mb-4">
          <Star className="h-6 w-6 text-blue-600 mr-2" />
          <h3 className="text-lg font-semibold text-blue-900">Quick Tips</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-sm">
            <h4 className="font-medium text-blue-900 mb-1">Before You Start</h4>
            <p className="text-blue-700">Try restarting your device first - it solves many common issues!</p>
          </div>
          <div className="text-sm">
            <h4 className="font-medium text-blue-900 mb-1">Document the Issue</h4>
            <p className="text-blue-700">Note any error messages or when the problem started occurring.</p>
          </div>
          <div className="text-sm">
            <h4 className="font-medium text-blue-900 mb-1">Still Stuck?</h4>
            <p className="text-blue-700">Create a support ticket with detailed information about your issue.</p>
          </div>
        </div>
      </div>

      {/* Troubleshooting Guides Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGuides.map((guide) => (
          <div
            key={guide.id}
            className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => setSelectedGuide(guide.id)}
          >
            {guide.imageUrl && (
              <div className="aspect-video bg-gray-200">
                <img
                  src={guide.imageUrl}
                  alt={guide.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className="p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded">
                  {guide.category}
                </span>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getDifficultyColor(guide.difficulty)}`}>
                  {guide.difficulty}
                </span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{guide.title}</h3>
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">{guide.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-500">
                  <Book className="h-4 w-4 mr-1" />
                  {guide.steps.length} steps
                </div>
                {guide.videoUrl && (
                  <div className="flex items-center text-sm text-blue-600">
                    <Play className="h-4 w-4 mr-1" />
                    Video
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredGuides.length === 0 && (
        <div className="text-center py-12">
          <Book className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No guides found</h3>
          <p className="text-gray-500">Try adjusting your search terms or browse all categories.</p>
        </div>
      )}
    </div>
  );
};

export default Troubleshooting;